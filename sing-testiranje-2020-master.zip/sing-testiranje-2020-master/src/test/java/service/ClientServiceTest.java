/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import model.Client;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author pavle
 */
public class ClientServiceTest {
    
    public ClientServiceTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of login method, of class ClientService.
     */
    @Test
    public void testLogin() {
        System.out.println("login");
        String username = "peric";
        String password = "peric";
        ClientService instance = new ClientService();
        Client expResult =  instance.login(username, password);
        Client result = instance.login(username, password);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testLogin2() {
        System.out.println("login");
        String username = "marko";
        String password = "marko";
        ClientService instance = new ClientService();
        Client expResult =  null;
        Client result = instance.login(username, password);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testLogin3() {
        System.out.println("login");
        String username = "perke";
        String password = "123";
        ClientService instance = new ClientService();
        Client expResult =  null;
        Client result = instance.login(username, password);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testLogin4() {
        System.out.println("login");
        String username = "milos";
        String password = "perke";
        ClientService instance = new ClientService();
        Client expResult =  null;
        Client result = instance.login(username, password);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testLogin5() {
        System.out.println("login");
        String username = "perke";
        String password = "";
        ClientService instance = new ClientService();
        Client expResult =  null;
        Client result = instance.login(username, password);
        assertEquals(expResult, result);
        
    }
    
    
    @Test
    public void testLogin6() {
        System.out.println("login");
        String username = "";
        String password = "perke";
        ClientService instance = new ClientService();
        Client expResult =  null;
        Client result = instance.login(username, password);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testLogin7() {
        System.out.println("login");
        String username = "";
        String password = "";
        ClientService instance = new ClientService();
        Client expResult =  null;
        Client result = instance.login(username, password);
        assertEquals(expResult, result);
        
    }

    /**
     * Test of register method, of class ClientService.
     */
    @Test
    public void testRegister() {
        System.out.println("register");
        String name = "jovana";
        String username = "jovana";
        String password = "jovana";
        ClientService instance = new ClientService();
        boolean expResult = true;
        boolean result = instance.register(name, username, password);
        assertEquals(expResult, result);
        
    }
    
    
    @Test
    public void testRegister2() {
        System.out.println("register");
        String name = "jovana98";
        String username = "jovana98";
        String password = "";
        ClientService instance = new ClientService();
        boolean expResult = false;
        boolean result = instance.register(name, username, password);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testRegister3() {
        System.out.println("register");
        String name = "jovana998";
        String username = "";
        String password = "jovana998";
        ClientService instance = new ClientService();
        boolean expResult = false;
        boolean result = instance.register(name, username, password);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testRegister4() {
        System.out.println("register");
        String name = "";
        String username = "jovana9988";
        String password = "jovana9988";
        ClientService instance = new ClientService();
        boolean expResult = false;
        boolean result = instance.register(name, username, password);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testRegister5() {
        System.out.println("register");
        String name = "jole";
        String username = "paki";
        String password = "123";
        ClientService instance = new ClientService();
        boolean expResult = false;
        boolean result = instance.register(name, username, password);
        assertEquals(expResult, result);
        
    }

    /**
     * Test of deleteUser method, of class ClientService.
     */
    @Test
    public void testDeleteUser() {
        System.out.println("deleteUser");
        Client c = new Client(3, "paca", "paca", "paca");
        ClientService instance = new ClientService();
        boolean expResult = true;
        boolean result = instance.deleteUser(c);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testDeleteUser2() {
        System.out.println("deleteUser");
        Client c = new Client(55, "neki", "neki", "neki");
        ClientService instance = new ClientService();
        boolean expResult = false;
        boolean result = instance.deleteUser(c);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testDeleteUser3() {
        System.out.println("deleteUser");
        Client c = new Client(50, "neki", "paki", "321");
        ClientService instance = new ClientService();
        boolean expResult = false;
        boolean result = instance.deleteUser(c);
        assertEquals(expResult, result);
        
    }

    /**
     * Test of updateInfo method, of class ClientService.
     */
    @Test
    public void testUpdateInfo() {
        System.out.println("updateInfo");
        Client c = new Client(5, "paja", "paja", "paja");
        String name = "ppp";
        String oldPassword = "paja";
        String password = "ppp";
        ClientService instance = new ClientService();
        instance.updateInfo(c, name, oldPassword, password);
        
    }
    
    @Test
    public void testUpdateInfo2() {
        System.out.println("updateInfo");
        Client c = new Client(76, "boza", "boza", "boza");
        String name = "bozidar";
        String oldPassword = "boza";
        String password = "bozidar";
        ClientService instance = new ClientService();
        instance.updateInfo(c, name, oldPassword, password);
        
    }
    
    @Test
    public void testUpdateInfo3() {
        System.out.println("updateInfo");
        Client c = new Client(6, "perke", "aaa", "aaa");
        String name = "perke98";
        String oldPassword = "aaa";
        String password = "bbb";
        ClientService instance = new ClientService();
        instance.updateInfo(c, name, oldPassword, password);
        
    }
    
}

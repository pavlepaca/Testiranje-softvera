/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import model.DeliveryService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author pavle
 */
public class DeliveryServiceServiceTest {
    
    public DeliveryServiceServiceTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of register method, of class DeliveryServiceService.
     */
    @Test
    public void testRegister() {
        System.out.println("register");
        String name = "dostavljac";
        float pricePerKilometer = 100F;
        float startingPrice = 100F;
        DeliveryServiceService instance = new DeliveryServiceService();
        boolean expResult = true;
        boolean result = instance.register(name, pricePerKilometer, startingPrice);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testRegister2() {
        System.out.println("register");
        String name = "dostavljac2";
        float pricePerKilometer = 200F;
        float startingPrice = 0.0F;
        DeliveryServiceService instance = new DeliveryServiceService();
        boolean expResult = false;
        boolean result = instance.register(name, pricePerKilometer, startingPrice);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testRegister3() {
        System.out.println("register");
        String name = "dostavljac3";
        float pricePerKilometer = 0.0F;
        float startingPrice = 200F;
        DeliveryServiceService instance = new DeliveryServiceService();
        boolean expResult = false;
        boolean result = instance.register(name, pricePerKilometer, startingPrice);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testRegister4() {
        System.out.println("register");
        String name = "";
        float pricePerKilometer = 200F;
        float startingPrice = 200F;
        DeliveryServiceService instance = new DeliveryServiceService();
        boolean expResult = false;
        boolean result = instance.register(name, pricePerKilometer, startingPrice);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testRegister5() {
        System.out.println("register");
        String name = "dostavljac5";
        float pricePerKilometer = 0.0F;
        float startingPrice = 0.0F;
        DeliveryServiceService instance = new DeliveryServiceService();
        boolean expResult = false;
        boolean result = instance.register(name, pricePerKilometer, startingPrice);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testRegister6() {
        System.out.println("register");
        String name = "dostavljac6";
        float pricePerKilometer = 99F;
        float startingPrice = -99F;
        DeliveryServiceService instance = new DeliveryServiceService();
        boolean expResult = false;
        boolean result = instance.register(name, pricePerKilometer, startingPrice);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testRegister7() {
        System.out.println("register");
        String name = "dostavljac7";
        float pricePerKilometer = -98F;
        float startingPrice = 98F;
        DeliveryServiceService instance = new DeliveryServiceService();
        boolean expResult = false;
        boolean result = instance.register(name, pricePerKilometer, startingPrice);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testRegister8() {
        System.out.println("register");
        String name = "dostavljac8";
        float pricePerKilometer = -97F;
        float startingPrice = -97F;
        DeliveryServiceService instance = new DeliveryServiceService();
        boolean expResult = false;
        boolean result = instance.register(name, pricePerKilometer, startingPrice);
        assertEquals(expResult, result);
        
    }

    /**
     * Test of deleteDeliveryService method, of class DeliveryServiceService.
     */
    @Test
    public void testDeleteDeliveryService() {
        System.out.println("deleteDeliveryService");
        DeliveryService d = new DeliveryService(3, "prevoz3", 20, 3);
        DeliveryServiceService instance = new DeliveryServiceService();
        boolean expResult = true;
        boolean result = instance.deleteDeliveryService(d);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testDeleteDeliveryService2() {
        System.out.println("deleteDeliveryService");
        DeliveryService d = new DeliveryService(47, "prevozimo", 47, 47);
        DeliveryServiceService instance = new DeliveryServiceService();
        boolean expResult = false;
        boolean result = instance.deleteDeliveryService(d);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testDeleteDeliveryService3() {
        System.out.println("deleteDeliveryService");
        DeliveryService d = new DeliveryService(48, "prevoz4", 48, 48);
        DeliveryServiceService instance = new DeliveryServiceService();
        boolean expResult = false;
        boolean result = instance.deleteDeliveryService(d);
        assertEquals(expResult, result);
        
    }

    /**
     * Test of updateInfo method, of class DeliveryServiceService.
     */
    @Test
    public void testUpdateInfo() {
        System.out.println("updateInfo");
        DeliveryService d = new DeliveryService(5, "prevoz5", 30, 5);
        String name = "transport";
        float startingPrice = 70F;
        float pricePerKilometer = 70F;
        DeliveryServiceService instance = new DeliveryServiceService();
        boolean expResult = true;
        boolean result = instance.updateInfo(d, name, startingPrice, pricePerKilometer);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testUpdateInfo2() {
        System.out.println("updateInfo");
        DeliveryService d = new DeliveryService(65, "pr", 23, 23);
        String name = "mmmmmm";
        float startingPrice = 32F;
        float pricePerKilometer = 32F;
        DeliveryServiceService instance = new DeliveryServiceService();
        boolean expResult = false;
        boolean result = instance.updateInfo(d, name, startingPrice, pricePerKilometer);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testUpdateInfo3() {
        System.out.println("updateInfo");
        DeliveryService d = new DeliveryService(44, "prevoz4", 27, 4);
        String name = "prevozgreska";
        float startingPrice = 45F;
        float pricePerKilometer = 45F;
        DeliveryServiceService instance = new DeliveryServiceService();
        boolean expResult = false;
        boolean result = instance.updateInfo(d, name, startingPrice, pricePerKilometer);
        assertEquals(expResult, result);
        
    }
    
    
    
}

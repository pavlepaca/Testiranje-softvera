/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import model.ShopItem;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author pavle
 */
public class ShopItemServiceTest {
    
    public ShopItemServiceTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of postItem method, of class ShopItemService.
     */
    @Test
    public void testPostItem() {
        System.out.println("postItem");
        String name = "kafa";
        float price = 2F;
        int amount = 2;
        ShopItemService instance = new ShopItemService();
        boolean expResult = true;
        boolean result = instance.postItem(name, price, amount);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testPostItem2() {
        System.out.println("postItem");
        String name = "kafa";
        float price = -3F;
        int amount = 3;
        ShopItemService instance = new ShopItemService();
        boolean expResult = false;
        boolean result = instance.postItem(name, price, amount);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testPostItem3() {
        System.out.println("postItem");
        String name = "kafa";
        float price = 4F;
        int amount = -4;
        ShopItemService instance = new ShopItemService();
        boolean expResult = false;
        boolean result = instance.postItem(name, price, amount);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testPostItem4() {
        System.out.println("postItem");
        String name = "";
        float price = 5F;
        int amount = 5;
        ShopItemService instance = new ShopItemService();
        boolean expResult = false;
        boolean result = instance.postItem(name, price, amount);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testPostItem5() {
        System.out.println("postItem");
        String name = "kafa";
        float price = -6F;
        int amount = -6;
        ShopItemService instance = new ShopItemService();
        boolean expResult = false;
        boolean result = instance.postItem(name, price, amount);
        assertEquals(expResult, result);
        
    }

    /**
     * Test of removeItem method, of class ShopItemService.
     */
    @Test
    public void testRemoveItem() {
        System.out.println("removeItem");
        ShopItem s = new ShopItem(3, "mleko", 130, 30);
        ShopItemService instance = new ShopItemService();
        boolean expResult = true;
        boolean result = instance.removeItem(s);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testRemoveItem2() {
        System.out.println("removeItem");
        ShopItem s = new ShopItem(91, "mleko", 92, 93);
        ShopItemService instance = new ShopItemService();
        boolean expResult = false;
        boolean result = instance.removeItem(s);
        assertEquals(expResult, result);
        
    }
    
    @Test
    public void testRemoveItem3() {
        System.out.println("removeItem");
        ShopItem s = new ShopItem(4, "secer", 54, 54);
        ShopItemService instance = new ShopItemService();
        boolean expResult = false;
        boolean result = instance.removeItem(s);
        assertEquals(expResult, result);
        
    }

    /**
     * Test of buy method, of class ShopItemService.
     */
    @Test
    public void testBuy() {
        System.out.println("buy");
        ShopItem s = new ShopItem(5, "mleko", 150, 50);
        int amount = 5;
        ShopItemService instance = new ShopItemService();
        instance.buy(s, amount);
        
    }
    
    @Test
    public void testBuy2() {
        System.out.println("buy");
        ShopItem s = new ShopItem(6, "mleko", 160, 60);
        int amount = 90;
        ShopItemService instance = new ShopItemService();
        instance.buy(s, amount);
        
    }
    
    @Test
    public void testBuy3() {
        System.out.println("buy");
        ShopItem s = new ShopItem(7, "mleko", 170, 70);
        int amount = -5;
        ShopItemService instance = new ShopItemService();
        instance.buy(s, amount);
        
    }
    
    @Test
    public void testBuy4() {
        System.out.println("buy");
        ShopItem s = new ShopItem(4, "mleko", 1, 1);
        int amount = 1;
        ShopItemService instance = new ShopItemService();
        instance.buy(s, amount);
        
    }
    
    
    @Test
    public void testBuy5() {
        System.out.println("buy");
        ShopItem s = new ShopItem(27, "mleko", 23, 21);
        int amount = 7;
        ShopItemService instance = new ShopItemService();
        instance.buy(s, amount);
        
    }

    /**
     * Test of stockUp method, of class ShopItemService.
     */
    @Test
    public void testStockUp() {
        System.out.println("stockUp");
        ShopItem s = new ShopItem(8, "mleko", 180, 80);
        int amount = 5;
        ShopItemService instance = new ShopItemService();
        instance.stockUp(s, amount);
        
    }
    
    @Test
    public void testStockUp2() {
        System.out.println("stockUp");
        ShopItem s = new ShopItem(9, "mleko", 190, 90);
        int amount = -5;
        ShopItemService instance = new ShopItemService();
        instance.stockUp(s, amount);
        
    }
    
    @Test
    public void testStockUp3() {
        System.out.println("stockUp");
        ShopItem s = new ShopItem(4, "secer", 12, 21);
        int amount = 5;
        ShopItemService instance = new ShopItemService();
        instance.stockUp(s, amount);
        
    }
    
    @Test
    public void testStockUp4() {
        System.out.println("stockUp");
        ShopItem s = new ShopItem(70, "mleko", 27, 27);
        int amount = 27;
        ShopItemService instance = new ShopItemService();
        instance.stockUp(s, amount);
        
    }

    /**
     * Test of checkIfPopular method, of class ShopItemService.
     */
    @Test
    public void testCheckIfPopular() {
        System.out.println("checkIfPopular");
        ShopItem s = null;
        ShopItemService instance = new ShopItemService();
        boolean expResult = false;
        boolean result = instance.checkIfPopular(s);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getTrendingIndex method, of class ShopItemService.
     */
    @Test
    public void testGetTrendingIndex() {
        System.out.println("getTrendingIndex");
        ShopItem s = null;
        ShopItemService instance = new ShopItemService();
        float expResult = 0.0F;
        float result = instance.getTrendingIndex(s);
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
